package presage;

public interface Input {
	
	public String getPerformative();

	public long getTimestamp();
	
	public void setTimestamp(long timestamp);
	
}
