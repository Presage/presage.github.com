package presage.util;

public class FileInfo {

	public String fileName;
	// public Method[] methods;

	public FileInfo(String fileName){ // , Method[] methods) {
		this.fileName = fileName;
		// this.methods = methods;
	}

	public String toString() {
		return fileName;
	}
}



