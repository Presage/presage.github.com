package presage;

import java.io.Serializable;
import java.util.UUID;


/**
 * 
 * The user should extend this class for every action they wish to support in the Simulation's Environment.
 *
 */
	public interface Action {
	
	// public String getParticipantId();	
		
	public String toString();
	
}