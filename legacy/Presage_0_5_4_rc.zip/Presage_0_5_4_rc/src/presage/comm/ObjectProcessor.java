package presage.comm;

public interface ObjectProcessor {
	
	public Object processObject(Object request);
	
}
