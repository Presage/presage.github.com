package infection;

import java.util.UUID;
import java.awt.Rectangle;
import presage.environment.messages.ENVRegistrationResponse;

public class ExampleRegResponse extends ENVRegistrationResponse {

	
	
	public ExampleRegResponse(String participantId, UUID participantAuthCode) {
		super(participantId, participantAuthCode);
		// TODO Auto-generated constructor stub
	}

}
